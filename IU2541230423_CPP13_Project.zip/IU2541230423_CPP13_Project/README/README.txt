=====================================================
VEHICLE SERVICE CENTER MANAGEMENT SYSTEM (CPP13)
Student ID: IU2541230423
=====================================================

FOLDER STRUCTURE:
- Source/      : All C++ header (.h) and implementation (.cpp) files
- Data/        : File persistence records (customers, vehicles, mechanics, jobs)
- Executable/  : Compiled application (Project.exe)
- Diagrams/    : UML Use Case, Class, and Sequence diagrams
- Screenshots/ : Program execution output images

HOW TO COMPILE AND RUN:
1. Open Command Prompt in the project root directory.
2. Compile command:
   g++ -std=c++11 Source/*.cpp -o Executable/Project.exe
3. Execution command:
   Executable\Project.exe

GITHUB REPOSITORY:
<Paste your public GitHub repository URL here>