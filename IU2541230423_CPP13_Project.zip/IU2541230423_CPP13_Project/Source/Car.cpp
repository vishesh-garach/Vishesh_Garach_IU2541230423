#include "Car.h"

Car::Car() : Vehicle(), numDoors(4) {}

Car::Car(int id, const std::string& plate, const std::string& b, int owner, int doors)
    : Vehicle(id, plate, b, owner), numDoors(doors) {}

Car::~Car() {}

double Car::calculateServiceCost() const {
    return 150.0 + (numDoors * 10.0);
}

void Car::displayDetails() const {
    std::cout << "[Car] ";
    Vehicle::displayDetails();
    std::cout << " | Doors: " << numDoors << " | Estimated Cost: $" << calculateServiceCost() << std::endl;
}

int Car::getNumDoors() const { return numDoors; }