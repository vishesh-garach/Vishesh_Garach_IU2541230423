#ifndef VEHICLE_H
#define VEHICLE_H

#include <string>
#include <iostream>

class Vehicle {
protected:
    int vehicleId;
    std::string licensePlate;
    std::string brand;
    int ownerId;

public:
    Vehicle();
    Vehicle(int id, const std::string& plate, const std::string& b, int owner);
    virtual ~Vehicle();

    virtual double calculateServiceCost() const = 0;
    virtual void displayDetails() const;

    int getVehicleId() const;
    int getOwnerId() const;
    std::string getLicensePlate() const;
    std::string getBrand() const;
};

#endif