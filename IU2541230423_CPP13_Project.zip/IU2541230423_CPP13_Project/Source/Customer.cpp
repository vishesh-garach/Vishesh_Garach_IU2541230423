#include "Customer.h"

Customer::Customer() : customerId(0), name(""), phone("") {}

Customer::Customer(int id, const std::string& n, const std::string& p)
    : customerId(id), name(n), phone(p) {}

Customer::~Customer() {}

int Customer::getId() const { return customerId; }
std::string Customer::getName() const { return name; }
std::string Customer::getPhone() const { return phone; }

void Customer::displayDetails() const {
    std::cout << "Customer ID: " << customerId << " | Name: " << name << " | Phone: " << phone << std::endl;
}