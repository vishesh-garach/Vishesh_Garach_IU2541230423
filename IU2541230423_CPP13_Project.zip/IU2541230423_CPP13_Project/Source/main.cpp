#include "ServiceCenter.h"

int main() {
    ServiceCenter center;
    center.runMenu();
    return 0;
}