#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <string>
#include <iostream>

class Customer {
private:
    int customerId;
    std::string name;
    std::string phone;

public:
    Customer();
    Customer(int id, const std::string& n, const std::string& p);
    ~Customer();

    int getId() const;
    std::string getName() const;
    std::string getPhone() const;

    void displayDetails() const;
};

#endif