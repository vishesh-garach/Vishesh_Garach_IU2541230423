#ifndef FILEMANAGER_H
#define FILEMANAGER_H

#include <string>

class FileManager {
private:
    std::string dataFolderPath;

public:
    FileManager();
    bool saveToFile(const std::string& fileName, const std::string& content);
    std::string readFromFile(const std::string& fileName);
};

#endif