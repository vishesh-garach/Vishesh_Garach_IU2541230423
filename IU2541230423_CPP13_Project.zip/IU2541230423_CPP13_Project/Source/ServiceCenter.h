#ifndef SERVICECENTER_H
#define SERVICECENTER_H

#include "Vehicle.h"
#include "Car.h"
#include "Motorcycle.h"
#include "Customer.h"
#include "Mechanic.h"
#include "ServiceJob.h"
#include "FileManager.h"

class ServiceCenter {
private:
    Vehicle** vehicles;
    Customer* customers;
    Mechanic* mechanics;
    ServiceJob* jobs;

    int vehicleCount;
    int customerCount;
    int mechanicCount;
    int jobCount;

    int capacity;
    FileManager fileMgr;

    void reallocateMemory();

public:
    ServiceCenter();
    ~ServiceCenter();

    void runMenu();
    void addRecord();
    void displayRecords() const;
    void searchRecord() const;
    void updateRecord();
    void deleteRecord();
    void processServiceJob();
    void generateReport() const;
    void saveAllData();
    void loadAllData();
};

#endif