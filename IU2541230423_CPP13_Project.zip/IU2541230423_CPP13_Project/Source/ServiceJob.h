#ifndef SERVICEJOB_H
#define SERVICEJOB_H

#include <string>
#include <iostream>

class ServiceJob {
private:
    int jobId;
    int vehicleId;
    int mechanicId;
    std::string serviceDetails;
    double cost;
    std::string status;

public:
    ServiceJob();
    ServiceJob(int jId, int vId, int mId, const std::string& details, double c);
    ~ServiceJob();

    int getJobId() const;
    int getVehicleId() const;
    int getMechanicId() const;
    std::string getServiceDetails() const;
    double getCost() const;
    std::string getStatus() const;

    void setStatus(const std::string& st);
    void displayJob() const;
};

#endif