#ifndef CAR_H
#define CAR_H

#include "Vehicle.h"

class Car : public Vehicle {
private:
    int numDoors;

public:
    Car();
    Car(int id, const std::string& plate, const std::string& b, int owner, int doors);
    ~Car() override;

    double calculateServiceCost() const override;
    void displayDetails() const override;

    int getNumDoors() const;
};

#endif