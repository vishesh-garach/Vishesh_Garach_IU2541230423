#include "Mechanic.h"

Mechanic::Mechanic() : mechanicId(0), name(""), specialization(""), isAvailable(true) {}

Mechanic::Mechanic(int id, const std::string& n, const std::string& spec)
    : mechanicId(id), name(n), specialization(spec), isAvailable(true) {}

Mechanic::~Mechanic() {}

int Mechanic::getId() const { return mechanicId; }
std::string Mechanic::getName() const { return name; }
std::string Mechanic::getSpecialization() const { return specialization; }
bool Mechanic::getAvailability() const { return isAvailable; }

void Mechanic::setAvailability(bool status) { isAvailable = status; }

void Mechanic::displayDetails() const {
    std::cout << "Mechanic ID: " << mechanicId 
              << " | Name: " << name 
              << " | Spec: " << specialization 
              << " | Status: " << (isAvailable ? "Available" : "Busy") << std::endl;
}