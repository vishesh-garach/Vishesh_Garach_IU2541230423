#include "Vehicle.h"

Vehicle::Vehicle() : vehicleId(0), licensePlate(""), brand(""), ownerId(0) {}

Vehicle::Vehicle(int id, const std::string& plate, const std::string& b, int owner)
    : vehicleId(id), licensePlate(plate), brand(b), ownerId(owner) {}

Vehicle::~Vehicle() {}

void Vehicle::displayDetails() const {
    std::cout << "ID: " << vehicleId 
              << " | Plate: " << licensePlate 
              << " | Brand: " << brand 
              << " | Owner ID: " << ownerId;
}

int Vehicle::getVehicleId() const { return vehicleId; }
int Vehicle::getOwnerId() const { return ownerId; }
std::string Vehicle::getLicensePlate() const { return licensePlate; }
std::string Vehicle::getBrand() const { return brand; }