#include "FileManager.h"
#include <fstream>
#include <sstream>

FileManager::FileManager() : dataFolderPath("../Data/") {}

bool FileManager::saveToFile(const std::string& fileName, const std::string& content) {
    std::ofstream file(dataFolderPath + fileName);
    if (!file.is_open()) {
        file.open(fileName); // Fallback to current folder if ../Data/ is inaccessible
    }
    if (file.is_open()) {
        file << content;
        file.close();
        return true;
    }
    return false;
}

std::string FileManager::readFromFile(const std::string& fileName) {
    std::ifstream file(dataFolderPath + fileName);
    if (!file.is_open()) {
        file.open(fileName);
    }
    if (file.is_open()) {
        std::stringstream buffer;
        buffer << file.rdbuf();
        file.close();
        return buffer.str();
    }
    return "";
}