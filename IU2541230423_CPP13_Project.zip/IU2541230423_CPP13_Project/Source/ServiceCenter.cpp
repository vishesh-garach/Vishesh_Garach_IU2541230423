#include "ServiceCenter.h"
#include <iostream>
#include <sstream>
#include <limits>

ServiceCenter::ServiceCenter() 
    : vehicleCount(0), customerCount(0), mechanicCount(0), jobCount(0), capacity(50) {
    vehicles = new Vehicle*[capacity];
    customers = new Customer[capacity];
    mechanics = new Mechanic[capacity];
    jobs = new ServiceJob[capacity];

    // Seed default mechanics
    mechanics[0] = Mechanic(101, "Alex Smith", "Engine & Transmission");
    mechanics[1] = Mechanic(102, "John Doe", "Brakes & Suspension");
    mechanicCount = 2;
}

ServiceCenter::~ServiceCenter() {
    for (int i = 0; i < vehicleCount; ++i) {
        delete vehicles[i];
    }
    delete[] vehicles;
    delete[] customers;
    delete[] mechanics;
    delete[] jobs;
}

void ServiceCenter::runMenu() {
    int choice = 0;
    loadAllData();

    do {
        std::cout << "\n=========================================\n";
        std::cout << "     VEHICLE SERVICE CENTER SYSTEM\n";
        std::cout << "=========================================\n";
        std::cout << "1. Add Record\n";
        std::cout << "2. Display Records\n";
        std::cout << "3. Search Record\n";
        std::cout << "4. Update Record\n";
        std::cout << "5. Delete Record\n";
        std::cout << "6. Main Transaction / Process Job\n";
        std::cout << "7. Generate Report\n";
        std::cout << "8. Save / Load Data\n";
        std::cout << "9. Exit\n";
        std::cout << "-----------------------------------------\n";
        std::cout << "Enter your choice (1-9): ";

        if (!(std::cin >> choice)) {
            std::cout << "Invalid input! Please enter a number.\n";
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            continue;
        }

        switch (choice) {
            case 1: addRecord(); break;
            case 2: displayRecords(); break;
            case 3: searchRecord(); break;
            case 4: updateRecord(); break;
            case 5: deleteRecord(); break;
            case 6: processServiceJob(); break;
            case 7: generateReport(); break;
            case 8: saveAllData(); std::cout << "Data processed successfully.\n"; break;
            case 9: saveAllData(); std::cout << "Exiting system. Goodbye!\n"; break;
            default: std::cout << "Invalid choice! Enter between 1 and 9.\n"; break;
        }
    } while (choice != 9);
}

void ServiceCenter::addRecord() {
    int type = 0;
    std::cout << "\n--- Add Record ---\n1. Customer\n2. Car\n3. Motorcycle\nChoice: ";
    std::cin >> type;

    if (type == 1) {
        int id; std::string name, phone;
        std::cout << "Enter Customer ID: "; std::cin >> id;
        std::cout << "Enter Name: "; std::cin.ignore(); std::getline(std::cin, name);
        std::cout << "Enter Phone: "; std::getline(std::cin, phone);
        customers[customerCount++] = Customer(id, name, phone);
        std::cout << "Customer added successfully!\n";
    } else if (type == 2) {
        int id, owner, doors; std::string plate, brand;
        std::cout << "Enter Vehicle ID: "; std::cin >> id;
        std::cout << "Enter License Plate: "; std::cin >> plate;
        std::cout << "Enter Brand: "; std::cin >> brand;
        std::cout << "Enter Owner Customer ID: "; std::cin >> owner;
        std::cout << "Enter Number of Doors: "; std::cin >> doors;
        vehicles[vehicleCount++] = new Car(id, plate, brand, owner, doors);
        std::cout << "Car registered successfully!\n";
    } else if (type == 3) {
        int id, owner, cc; std::string plate, brand;
        std::cout << "Enter Vehicle ID: "; std::cin >> id;
        std::cout << "Enter License Plate: "; std::cin >> plate;
        std::cout << "Enter Brand: "; std::cin >> brand;
        std::cout << "Enter Owner Customer ID: "; std::cin >> owner;
        std::cout << "Enter Engine CC: "; std::cin >> cc;
        vehicles[vehicleCount++] = new Motorcycle(id, plate, brand, owner, cc);
        std::cout << "Motorcycle registered successfully!\n";
    } else {
        std::cout << "Invalid record type!\n";
    }
}

void ServiceCenter::displayRecords() const {
    std::cout << "\n================ CUSTOMERS ================\n";
    for (int i = 0; i < customerCount; ++i) customers[i].displayDetails();

    std::cout << "\n================ VEHICLES ================\n";
    for (int i = 0; i < vehicleCount; ++i) vehicles[i]->displayDetails();

    std::cout << "\n================ MECHANICS ================\n";
    for (int i = 0; i < mechanicCount; ++i) mechanics[i].displayDetails();

    std::cout << "\n================ SERVICE JOBS ================\n";
    for (int i = 0; i < jobCount; ++i) jobs[i].displayJob();
}

void ServiceCenter::searchRecord() const {
    int id;
    std::cout << "\nEnter Vehicle ID to Search: ";
    std::cin >> id;

    for (int i = 0; i < vehicleCount; ++i) {
        if (vehicles[i]->getVehicleId() == id) {
            std::cout << "Vehicle Found: ";
            vehicles[i]->displayDetails();
            return;
        }
    }
    std::cout << "Vehicle record not found!\n";
}

void ServiceCenter::updateRecord() {
    int id;
    std::cout << "\nEnter Customer ID to Update: ";
    std::cin >> id;

    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].getId() == id) {
            std::string name, phone;
            std::cout << "Enter New Name: "; std::cin.ignore(); std::getline(std::cin, name);
            std::cout << "Enter New Phone: "; std::getline(std::cin, phone);
            customers[i] = Customer(id, name, phone);
            std::cout << "Customer updated successfully!\n";
            return;
        }
    }
    std::cout << "Customer ID not found!\n";
}

void ServiceCenter::deleteRecord() {
    int id;
    std::cout << "\nEnter Customer ID to Delete: ";
    std::cin >> id;

    for (int i = 0; i < customerCount; ++i) {
        if (customers[i].getId() == id) {
            for (int j = i; j < customerCount - 1; ++j) {
                customers[j] = customers[j + 1];
            }
            customerCount--;
            std::cout << "Customer record deleted!\n";
            return;
        }
    }
    std::cout << "Customer ID not found!\n";
}

void ServiceCenter::processServiceJob() {
    if (vehicleCount == 0 || mechanicCount == 0) {
        std::cout << "Cannot process job. Ensure vehicles and mechanics exist.\n";
        return;
    }

    int vId, jId = jobCount + 1;
    std::string details;

    std::cout << "\n--- Create Service Job ---\n";
    std::cout << "Enter Vehicle ID for Service: "; std::cin >> vId;

    Vehicle* selectedVehicle = nullptr;
    for (int i = 0; i < vehicleCount; ++i) {
        if (vehicles[i]->getVehicleId() == vId) {
            selectedVehicle = vehicles[i];
            break;
        }
    }

    if (!selectedVehicle) {
        std::cout << "Vehicle ID not found!\n";
        return;
    }

    std::cout << "Enter Service Details: "; std::cin.ignore(); std::getline(std::cin, details);
    
    // Assign mechanic
    int mId = mechanics[0].getId();
    double cost = selectedVehicle->calculateServiceCost();

    jobs[jobCount++] = ServiceJob(jId, vId, mId, details, cost);
    std::cout << "Service Job successfully created! Assigned Mechanic ID: " << mId << " | Estimated Cost: $" << cost << "\n";
}

void ServiceCenter::generateReport() const {
    double totalRevenue = 0.0;
    std::cout << "\n================ SERVICE CENTER SUMMARY REPORT ================\n";
    std::cout << "Total Customers: " << customerCount << "\n";
    std::cout << "Total Registered Vehicles: " << vehicleCount << "\n";
    std::cout << "Total Service Jobs: " << jobCount << "\n";

    for (int i = 0; i < jobCount; ++i) {
        totalRevenue += jobs[i].getCost();
    }
    std::cout << "Total Estimated Revenue: $" << totalRevenue << "\n";
    std::cout << "===============================================================\n";
}

void ServiceCenter::saveAllData() {
    std::stringstream ssCust;
    for (int i = 0; i < customerCount; ++i) {
        ssCust << customers[i].getId() << "," << customers[i].getName() << "," << customers[i].getPhone() << "\n";
    }
    fileMgr.saveToFile("customers.txt", ssCust.str());

    std::stringstream ssVeh;
    for (int i = 0; i < vehicleCount; ++i) {
        ssVeh << vehicles[i]->getVehicleId() << "," << vehicles[i]->getLicensePlate() << "," 
              << vehicles[i]->getBrand() << "," << vehicles[i]->getOwnerId() << "\n";
    }
    fileMgr.saveToFile("vehicles.txt", ssVeh.str());

    std::stringstream ssJobs;
    for (int i = 0; i < jobCount; ++i) {
        ssJobs << jobs[i].getJobId() << "," << jobs[i].getVehicleId() << "," 
               << jobs[i].getMechanicId() << "," << jobs[i].getServiceDetails() << "," 
               << jobs[i].getCost() << "," << jobs[i].getStatus() << "\n";
    }
    fileMgr.saveToFile("jobs.txt", ssJobs.str());
}

void ServiceCenter::loadAllData() {
    std::string custData = fileMgr.readFromFile("customers.txt");
    if (!custData.empty()) {
        std::stringstream ss(custData);
        std::string line;
        while (std::getline(ss, line)) {
            if (line.empty()) continue;
            std::stringstream lineSS(line);
            std::string idStr, name, phone;
            std::getline(lineSS, idStr, ',');
            std::getline(lineSS, name, ',');
            std::getline(lineSS, phone, ',');
            if (!idStr.empty()) {
                customers[customerCount++] = Customer(std::stoi(idStr), name, phone);
            }
        }
    }
}