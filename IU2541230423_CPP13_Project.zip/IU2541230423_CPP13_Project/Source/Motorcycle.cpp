#include "Motorcycle.h"

Motorcycle::Motorcycle() : Vehicle(), engineCC(150) {}

Motorcycle::Motorcycle(int id, const std::string& plate, const std::string& b, int owner, int cc)
    : Vehicle(id, plate, b, owner), engineCC(cc) {}

Motorcycle::~Motorcycle() {}

double Motorcycle::calculateServiceCost() const {
    return 80.0 + (engineCC * 0.05);
}

void Motorcycle::displayDetails() const {
    std::cout << "[Motorcycle] ";
    Vehicle::displayDetails();
    std::cout << " | CC: " << engineCC << " | Estimated Cost: $" << calculateServiceCost() << std::endl;
}

int Motorcycle::getEngineCC() const { return engineCC; }