#ifndef MOTORCYCLE_H
#define MOTORCYCLE_H

#include "Vehicle.h"

class Motorcycle : public Vehicle {
private:
    int engineCC;

public:
    Motorcycle();
    Motorcycle(int id, const std::string& plate, const std::string& b, int owner, int cc);
    ~Motorcycle() override;

    double calculateServiceCost() const override;
    void displayDetails() const override;

    int getEngineCC() const;
};

#endif