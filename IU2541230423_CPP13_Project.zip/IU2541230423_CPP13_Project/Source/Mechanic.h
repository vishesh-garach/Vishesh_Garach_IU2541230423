#ifndef MECHANIC_H
#define MECHANIC_H

#include <string>
#include <iostream>

class Mechanic {
private:
    int mechanicId;
    std::string name;
    std::string specialization;
    bool isAvailable;

public:
    Mechanic();
    Mechanic(int id, const std::string& n, const std::string& spec);
    ~Mechanic();

    int getId() const;
    std::string getName() const;
    std::string getSpecialization() const;
    bool getAvailability() const;

    void setAvailability(bool status);
    void displayDetails() const;
};

#endif