#include "ServiceJob.h"

ServiceJob::ServiceJob() : jobId(0), vehicleId(0), mechanicId(0), serviceDetails(""), cost(0.0), status("Pending") {}

ServiceJob::ServiceJob(int jId, int vId, int mId, const std::string& details, double c)
    : jobId(jId), vehicleId(vId), mechanicId(mId), serviceDetails(details), cost(c), status("In Progress") {}

ServiceJob::~ServiceJob() {}

int ServiceJob::getJobId() const { return jobId; }
int ServiceJob::getVehicleId() const { return vehicleId; }
int ServiceJob::getMechanicId() const { return mechanicId; }
std::string ServiceJob::getServiceDetails() const { return serviceDetails; }
double ServiceJob::getCost() const { return cost; }
std::string ServiceJob::getStatus() const { return status; }

void ServiceJob::setStatus(const std::string& st) { status = st; }

void ServiceJob::displayJob() const {
    std::cout << "Job ID: " << jobId 
              << " | Vehicle ID: " << vehicleId 
              << " | Mechanic ID: " << mechanicId 
              << " | Details: " << serviceDetails 
              << " | Cost: $" << cost 
              << " | Status: " << status << std::endl;
}